# Tuinoverzicht

Statische site — geen build-tools, geen externe diensten, geen backend. Werkt met platte HTML/CSS/JS en twee JSON-bestanden als "database".

## Hoe de data werkt

- `data/garden.json` is de **gepubliceerde** staat van je tuin: zones, planten, achtergrondfoto-instellingen. Dit bestand staat gewoon in git.
- `data/soorten.json` is een kennisbank met snoei-info per plantensoort, gebruikt voor suggesties bij het toevoegen van een plant.
- Zet je "Bewerken" aan in de site, dan worden je wijzigingen **alleen lokaal in je eigen browser** opgeslagen (localStorage) — niet automatisch gedeeld met bezoekers.
- Om wijzigingen echt publiek te maken: klik **Exporteren** (downloadt een nieuwe `garden.json`), vervang daarmee `data/garden.json` in de repo, en commit + push. GitHub Pages ververst de site automatisch na een paar minuten.
- **Herstel gepubliceerd** gooit je lokale wijzigingen weg en laadt weer de laatst gepubliceerde `garden.json`. Handig nadat je hebt gepusht.

Dit betekent: iedereen die de site bezoekt kan technisch de bewerkknop zien en lokaal spelen, maar dat raakt nooit de echte data — alleen jij kunt publiceren, omdat alleen jij naar de repo kunt pushen.

## Luchtfoto instellen

1. Zet je foto in de map `img/`, bijvoorbeeld `img/plattegrond.jpg`.
2. Zet Bewerken aan → op de Kaart-pagina verschijnt een paneel om het bestandspad, de positie (pan) en zoom in te stellen. Zo kun je de foto uitlijnen en irrelevante randen buiten beeld schuiven zonder het originele bestand te bewerken.
3. Wil je een deel echt wegsnijden (bijvoorbeeld het huis van de buren), doe dat vooraf in een los fotobewerkingsprogramma en vervang het bestand in `img/`.

## Van nul naar live site op GitHub Pages

1. **Maak een GitHub-account** op github.com als je die nog niet hebt.
2. **Nieuwe repository aanmaken**: klik rechtsboven op de "+" → "New repository". Geef een naam (bv. `tuin`), zet 'm op **Public** (nodig voor gratis GitHub Pages), vink niets extra's aan, klik "Create repository".
3. **Bestanden uploaden**: op de lege repo-pagina klik je op "uploading an existing file". Sleep alle bestanden en mappen uit deze projectmap (`index.html`, `style.css`, `app.js`, `data/`, `img/`, dit `README.md`) erin. Commit de upload.
4. **GitHub Pages aanzetten**: ga naar Settings → Pages (linkermenu). Bij "Build and deployment" → Source kies je "Deploy from a branch". Bij Branch kies je `main` en map `/ (root)`. Klik Save.
5. Na ongeveer een minuut verschijnt bovenaan die pagina de link naar je site, iets als `https://jouwgebruikersnaam.github.io/tuin/`. Dat is de publieke, alleen-lezen link die je kunt delen.
6. **Wijzigingen publiceren**: bewerk lokaal in de site → Exporteren → ga naar je repo op GitHub → open `data/garden.json` → klik het potloodicoon (bewerken) → plak de nieuwe inhoud → Commit changes. Na een paar minuten staat de update live.

Geen command line nodig — dit kan allemaal via de GitHub-website.
